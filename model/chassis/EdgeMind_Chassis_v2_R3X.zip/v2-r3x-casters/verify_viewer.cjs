const fs=require('fs');
const path=require('path');
const {pathToFileURL}=require('url');
const {chromium}=require('C:/Users/Shan_/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
(async()=>{
 const out=__dirname;
 const expected=JSON.parse(fs.readFileSync(path.join(out,'verification.json'),'utf8')).parts.length;
 const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'});
 try{
  const page=await browser.newPage({viewport:{width:1920,height:1280},deviceScaleFactor:1});
  const errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
  await page.goto(pathToFileURL(path.join(out,'查看模型.html')).href);
  await page.waitForFunction(()=>window.chassisViewerState?.rendered);
  const initial=await page.evaluate(()=>window.chassisViewerState);
  if(initial.parts!==expected)throw new Error('Mesh count mismatch');
  await page.screenshot({path:path.join(out,'preview-viewer.png')});
  await page.locator('#view').screenshot({path:path.join(out,'preview-assembled.png')});
  await page.locator('#explode').evaluate(el=>{el.value='65';el.dispatchEvent(new Event('input',{bubbles:true}))});
  const exploded=await page.evaluate(()=>window.chassisViewerState);
  if(!exploded.upper_parts.length||exploded.upper_parts.some(p=>p.lift!==65))throw new Error('Upper assembly did not lift together');
  await page.locator('#view').screenshot({path:path.join(out,'preview-exploded.png')});
  await page.locator('#explode').evaluate(el=>{el.value='0';el.dispatchEvent(new Event('input',{bubbles:true}))});
  await page.locator('#upper').uncheck();
  const hiddenUpper=await page.evaluate(()=>window.chassisViewerState);
  if(hiddenUpper.upper_parts.some(p=>p.visible))throw new Error('Upper assembly visibility failed');
  await page.evaluate(()=>window.setChassisView(-.95,.75,560));
  await page.locator('#view').screenshot({path:path.join(out,'preview-battery-fence.png')});
  await page.locator('#electronics').uncheck();await page.locator('#fasteners').uncheck();
  await page.locator('#view').screenshot({path:path.join(out,'preview-shell.png')});
  await page.locator('#upper').check();await page.locator('#electronics').check();await page.locator('#fasteners').check();
  await page.locator('#top').click();await page.locator('#view').screenshot({path:path.join(out,'preview-top.png')});
  await page.evaluate(()=>window.setChassisView(-.95,2.25,620));
  await page.locator('#view').screenshot({path:path.join(out,'preview-underside.png')});
  await page.locator('#reset').click();
  if(errors.length)throw new Error(JSON.stringify(errors));
  fs.writeFileSync(path.join(out,'viewer-verification.json'),JSON.stringify({file_uri_works:true,mesh_count:expected,initial,exploded,hiddenUpper,console_errors:errors},null,2));
  console.log(JSON.stringify({rendered:true,parts:expected,upper_group_lifts_together:true,battery_fence_visible:true,console_errors:errors}));
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
