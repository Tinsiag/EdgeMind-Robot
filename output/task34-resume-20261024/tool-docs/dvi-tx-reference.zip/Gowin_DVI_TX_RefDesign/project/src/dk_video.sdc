create_clock -name I_clk -period 20 -waveform {0 10} [get_ports {I_clk}] -add
