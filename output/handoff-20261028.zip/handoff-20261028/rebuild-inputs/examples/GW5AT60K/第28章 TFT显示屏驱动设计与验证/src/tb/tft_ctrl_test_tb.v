/////////////////////////////////////////////////////////////////////////////////
// Company: �人о·��Ƽ����޹�˾
// Engineer: С÷���Ŷ�
// Web: www.corecourse.cn
// 
// Create Date: 2020/07/20 00:00:00
// Design Name: tft_ctrl_test
// Module Name: tft_ctrl_test_tb
// Project Name: tft_ctrl_test
// Target Devices: XC7A35T-2FGG484I
// Tool Versions: Vivado 2018.3
// Description: tft_ctrl_testģ������ļ�
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
`timescale 1ns / 1ns
`define CLK_PERIOD 20

module tft_ctrl_test_tb();

	reg          clk50M         ;
	reg          reset_n        ;

	wire  [15:0] TFT_rgb        ;
	wire         TFT_hs         ;
	wire         TFT_vs         ;
	wire         TFT_clk        ;
	wire         TFT_de         ;
	wire         TFT_pwm        ;

	initial clk50M = 1;
	always#(`CLK_PERIOD/2)clk50M = ~clk50M;

  initial begin
    reset_n = 1'b0;
    #(`CLK_PERIOD*20 + 1 );
    reset_n = 1'b1;
    #(`CLK_PERIOD*50);
    
    @(posedge TFT_vs);
    @(posedge TFT_vs);
    $stop;	
  end

tft_ctrl_test tft_ctrl_test
(
	.clk50M         (clk50M        ), //50MHzʱ������
	.reset_n        (reset_n       ), //�첽��λ�źţ�����Ч

	.TFT_rgb        (TFT_rgb       ), //TFT�������
	.TFT_hs         (TFT_hs        ), //TFT��ͬ���ź�
	.TFT_vs         (TFT_vs        ), //TFT��ͬ���ź�
	.TFT_clk        (TFT_clk       ), //TFT����ʱ��
	.TFT_de         (TFT_de        ), //TFT����ʹ��
	.TFT_pwm        (TFT_pwm       )  //TFT�������
);

endmodule
