//Copyright (C)2014-2025 Gowin Semiconductor Corporation.
//All rights reserved.
//File Title: Template file for instantiation
//Tool Version: V1.9.11.03 (64-bit)
//Part Number: GW5AT-LV60PG484AC1/I0
//Device: GW5AT-60
//Device Version: B
//Created Time: Thu Jul 10 11:47:17 2025

//Change the instance name and port connections to the signal names
//--------Copy here to design--------

	Gowin_DDR your_instance_name(
		.din(din), //input [7:0] din
		.clk(clk), //input clk
		.q(q) //output [3:0] q
	);

//--------Copy end-------------------
