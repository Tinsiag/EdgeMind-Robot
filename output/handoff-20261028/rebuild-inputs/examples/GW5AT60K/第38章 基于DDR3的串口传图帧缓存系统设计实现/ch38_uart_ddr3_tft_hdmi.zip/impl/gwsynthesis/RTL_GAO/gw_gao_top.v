module gw_gao(
    \image_data[15] ,
    \image_data[14] ,
    \image_data[13] ,
    \image_data[12] ,
    \image_data[11] ,
    \image_data[10] ,
    \image_data[9] ,
    \image_data[8] ,
    \image_data[7] ,
    \image_data[6] ,
    \image_data[5] ,
    \image_data[4] ,
    \image_data[3] ,
    \image_data[2] ,
    \image_data[1] ,
    \image_data[0] ,
    image_data_valid,
    rdfifo_rden,
    \rdfifo_dout[15] ,
    \rdfifo_dout[14] ,
    \rdfifo_dout[13] ,
    \rdfifo_dout[12] ,
    \rdfifo_dout[11] ,
    \rdfifo_dout[10] ,
    \rdfifo_dout[9] ,
    \rdfifo_dout[8] ,
    \rdfifo_dout[7] ,
    \rdfifo_dout[6] ,
    \rdfifo_dout[5] ,
    \rdfifo_dout[4] ,
    \rdfifo_dout[3] ,
    \rdfifo_dout[2] ,
    \rdfifo_dout[1] ,
    \rdfifo_dout[0] ,
    \uart_byte[7] ,
    \uart_byte[6] ,
    \uart_byte[5] ,
    \uart_byte[4] ,
    \uart_byte[3] ,
    \uart_byte[2] ,
    \uart_byte[1] ,
    \uart_byte[0] ,
    uart_byte_vaild,
    loc_clk50m,
    tms_pad_i,
    tck_pad_i,
    tdi_pad_i,
    tdo_pad_o
);

input \image_data[15] ;
input \image_data[14] ;
input \image_data[13] ;
input \image_data[12] ;
input \image_data[11] ;
input \image_data[10] ;
input \image_data[9] ;
input \image_data[8] ;
input \image_data[7] ;
input \image_data[6] ;
input \image_data[5] ;
input \image_data[4] ;
input \image_data[3] ;
input \image_data[2] ;
input \image_data[1] ;
input \image_data[0] ;
input image_data_valid;
input rdfifo_rden;
input \rdfifo_dout[15] ;
input \rdfifo_dout[14] ;
input \rdfifo_dout[13] ;
input \rdfifo_dout[12] ;
input \rdfifo_dout[11] ;
input \rdfifo_dout[10] ;
input \rdfifo_dout[9] ;
input \rdfifo_dout[8] ;
input \rdfifo_dout[7] ;
input \rdfifo_dout[6] ;
input \rdfifo_dout[5] ;
input \rdfifo_dout[4] ;
input \rdfifo_dout[3] ;
input \rdfifo_dout[2] ;
input \rdfifo_dout[1] ;
input \rdfifo_dout[0] ;
input \uart_byte[7] ;
input \uart_byte[6] ;
input \uart_byte[5] ;
input \uart_byte[4] ;
input \uart_byte[3] ;
input \uart_byte[2] ;
input \uart_byte[1] ;
input \uart_byte[0] ;
input uart_byte_vaild;
input loc_clk50m;
input tms_pad_i;
input tck_pad_i;
input tdi_pad_i;
output tdo_pad_o;

wire \image_data[15] ;
wire \image_data[14] ;
wire \image_data[13] ;
wire \image_data[12] ;
wire \image_data[11] ;
wire \image_data[10] ;
wire \image_data[9] ;
wire \image_data[8] ;
wire \image_data[7] ;
wire \image_data[6] ;
wire \image_data[5] ;
wire \image_data[4] ;
wire \image_data[3] ;
wire \image_data[2] ;
wire \image_data[1] ;
wire \image_data[0] ;
wire image_data_valid;
wire rdfifo_rden;
wire \rdfifo_dout[15] ;
wire \rdfifo_dout[14] ;
wire \rdfifo_dout[13] ;
wire \rdfifo_dout[12] ;
wire \rdfifo_dout[11] ;
wire \rdfifo_dout[10] ;
wire \rdfifo_dout[9] ;
wire \rdfifo_dout[8] ;
wire \rdfifo_dout[7] ;
wire \rdfifo_dout[6] ;
wire \rdfifo_dout[5] ;
wire \rdfifo_dout[4] ;
wire \rdfifo_dout[3] ;
wire \rdfifo_dout[2] ;
wire \rdfifo_dout[1] ;
wire \rdfifo_dout[0] ;
wire \uart_byte[7] ;
wire \uart_byte[6] ;
wire \uart_byte[5] ;
wire \uart_byte[4] ;
wire \uart_byte[3] ;
wire \uart_byte[2] ;
wire \uart_byte[1] ;
wire \uart_byte[0] ;
wire uart_byte_vaild;
wire loc_clk50m;
wire tms_pad_i;
wire tck_pad_i;
wire tdi_pad_i;
wire tdo_pad_o;
wire tms_i_c;
wire tck_i_c;
wire tdi_i_c;
wire tdo_o_c;
wire [9:0] control0;
wire gao_jtag_tck;
wire gao_jtag_reset;
wire run_test_idle_er1;
wire run_test_idle_er2;
wire shift_dr_capture_dr;
wire update_dr;
wire pause_dr;
wire enable_er1;
wire enable_er2;
wire gao_jtag_tdi;
wire tdo_er1;

IBUF tms_ibuf (
    .I(tms_pad_i),
    .O(tms_i_c)
);

IBUF tck_ibuf (
    .I(tck_pad_i),
    .O(tck_i_c)
);

IBUF tdi_ibuf (
    .I(tdi_pad_i),
    .O(tdi_i_c)
);

OBUF tdo_obuf (
    .I(tdo_o_c),
    .O(tdo_pad_o)
);

GW_JTAG  u_gw_jtag(
    .tms_pad_i(tms_i_c),
    .tck_pad_i(tck_i_c),
    .tdi_pad_i(tdi_i_c),
    .tdo_pad_o(tdo_o_c),
    .tck_o(gao_jtag_tck),
    .test_logic_reset_o(gao_jtag_reset),
    .run_test_idle_er1_o(run_test_idle_er1),
    .run_test_idle_er2_o(run_test_idle_er2),
    .shift_dr_capture_dr_o(shift_dr_capture_dr),
    .update_dr_o(update_dr),
    .pause_dr_o(pause_dr),
    .enable_er1_o(enable_er1),
    .enable_er2_o(enable_er2),
    .tdi_o(gao_jtag_tdi),
    .tdo_er1_i(tdo_er1),
    .tdo_er2_i(1'b0)
);

gw_con_top  u_icon_top(
    .tck_i(gao_jtag_tck),
    .tdi_i(gao_jtag_tdi),
    .tdo_o(tdo_er1),
    .rst_i(gao_jtag_reset),
    .control0(control0[9:0]),
    .enable_i(enable_er1),
    .shift_dr_capture_dr_i(shift_dr_capture_dr),
    .update_dr_i(update_dr)
);

ao_top_0  u_la0_top(
    .control(control0[9:0]),
    .trig0_i(uart_byte_vaild),
    .data_i({\image_data[15] ,\image_data[14] ,\image_data[13] ,\image_data[12] ,\image_data[11] ,\image_data[10] ,\image_data[9] ,\image_data[8] ,\image_data[7] ,\image_data[6] ,\image_data[5] ,\image_data[4] ,\image_data[3] ,\image_data[2] ,\image_data[1] ,\image_data[0] ,image_data_valid,rdfifo_rden,\rdfifo_dout[15] ,\rdfifo_dout[14] ,\rdfifo_dout[13] ,\rdfifo_dout[12] ,\rdfifo_dout[11] ,\rdfifo_dout[10] ,\rdfifo_dout[9] ,\rdfifo_dout[8] ,\rdfifo_dout[7] ,\rdfifo_dout[6] ,\rdfifo_dout[5] ,\rdfifo_dout[4] ,\rdfifo_dout[3] ,\rdfifo_dout[2] ,\rdfifo_dout[1] ,\rdfifo_dout[0] ,\uart_byte[7] ,\uart_byte[6] ,\uart_byte[5] ,\uart_byte[4] ,\uart_byte[3] ,\uart_byte[2] ,\uart_byte[1] ,\uart_byte[0] ,uart_byte_vaild}),
    .clk_i(loc_clk50m)
);

endmodule
