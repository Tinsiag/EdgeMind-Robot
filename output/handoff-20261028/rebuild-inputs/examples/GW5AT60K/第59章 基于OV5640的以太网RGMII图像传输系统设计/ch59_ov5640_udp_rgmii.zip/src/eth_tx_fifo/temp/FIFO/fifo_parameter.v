parameter WDEPTH = 4096;
parameter WDSIZE = 16;
parameter RDEPTH = 8192;
parameter RDSIZE = 8;
parameter AEMPT = 1;
parameter AFULL = 1;
parameter ASIZE = 12;
parameter RASIZE = 13;
