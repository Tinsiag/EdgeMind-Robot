`define module_name eth_tx_fifo
`define getname(oriName,tmodule_name) \~oriName.tmodule_name 
`define EBR_BASED
`define FWFT
`define Al_Empty_Flag
`define Empty_S_Single_Th
`define Al_Full_Flag
`define Full_S_Single_Th
`define Count_R
`define En_Reset
`define Reset_Synchronization
